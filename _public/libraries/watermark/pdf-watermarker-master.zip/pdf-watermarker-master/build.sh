composer install
cd tests
phpunit pdfwatermarker-test.php
phpunit pdfwatermark-test.php